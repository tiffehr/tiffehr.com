import{l as o,u as a,c as t,a as c,b as l}from"./DVsecn7X.js";function f(n){t===null&&o(),c&&t.l!==null?u(t).m.push(n):a(()=>{const e=l(n);if(typeof e=="function")return e})}function u(n){var e=n.l;return e.u??={a:[],b:[],m:[]}}export{f as o};
//# sourceMappingURL=BMW5ReW2.js.map
